@extends('admin.layouts.general')

@section('content')
<div class="col-md-12">
    <h1>DASHBOARD</h1>
</div>
@endsection
