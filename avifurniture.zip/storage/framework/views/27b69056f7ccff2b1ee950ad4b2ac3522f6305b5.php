<?php $__env->startSection('content'); ?>
<section class="breadscrumb-section pt-0">
    <div class="container-fluid-lg">
        <div class="row">
            <div class="col-12">
                <div class="breadscrumb-contain">
                    <h2>Our Products</h2>
                    <nav>
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(url('/')); ?>">
                                    Home
                                </a>
                            </li>
                            <?php if(isset($category)): ?>
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(url('/products')); ?>">Products</a>
                                </li>
                                <li class="breadcrumb-item active">
                                    <?php echo e($category->name); ?>

                                </li>
                            <?php else: ?>
                            <li class="breadcrumb-item active">
                                Product
                            </li>
                            <?php endif; ?>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="product-section">
    <div class="container-fluid-lg">
        <div class="row g-8">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xxl-2 col-lg-3 col-md-4 col-6 wow fadeInUp">
                <div class="product-box-4 shadow">
                    <div class="product-image">
                        <a href="<?php echo e(url('/product', $result->slug)); ?>">
                            <img src="<?php echo e(asset('uploads/product/'.$result->image)); ?>" class="rounded" alt="<?php echo e($result->name); ?>">
                        </a>

                        <ul class="option">
                            <li data-bs-toggle="tooltip" data-bs-placement="top" title="Quick View">
                                <a href="<?php echo e(url('/product', $result->slug)); ?>">
                                    <i class="iconly-Show icli"></i>
                                </a>
                            </li>
                        </ul>
                    </div>

                    <div class="product-detail">
                        <h3 class="d-block mb-3">
                            <?php if($result->price !== null): ?>
                                Rp. <?php echo e(number_format($result->price,0,',','.')); ?>

                            <?php else: ?>
                                Contact Admin
                            <?php endif; ?>
                        </h3>
                        <a href="<?php echo e(url('/product', $result->slug)); ?>">
                            <h4 ><?php echo e($result->name); ?></h4>
                        </a>
                        <span class="text-secondary">
                            <?php if($result->product_category_id !== 0): ?>
                                <?php echo e($result->productCategory->name); ?>

                            <?php else: ?>
                                Uncategorized
                            <?php endif; ?>
                        </span>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(count($products) == 0): ?>
                <div class="col-md-12">
                    <div class="d-flex justify-content-center">
                        <h2>Sorry!! Produk kosong</h2>
                    </div>
                </div>
            <?php endif; ?>

            <div class="col-md-12 mb-4">
                <div class="d-flex justify-content-center">
                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\avifurniture\resources\views/product.blade.php ENDPATH**/ ?>