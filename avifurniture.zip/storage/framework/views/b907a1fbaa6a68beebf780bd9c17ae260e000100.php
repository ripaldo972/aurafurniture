<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h1>GALLERY PRODUCT</h1>
</div>

<div class="col-md-4 mb-3">
    <h3>Add New Category</h3>
    <form action="<?php echo e(route('category.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">Product</label>
            <select name="product_id" class="form-select" required>

            </select>
            <span class="text-muted"><i>Products are the key to adding to the gallery.</i></span> <br>
        </div>
        <div class="mb-3">
            <label class="form-lable">Image</label>
            <input type="file" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image" accept="image/*">
            <span class="text-muted"><i>We recommend an image size for categories of <b>100 x 100 pixels</b>.</i></span>
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">
            <button class="btn btn-primary">Add New Category</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\avifurniture\resources\views/admin/gallery/index.blade.php ENDPATH**/ ?>