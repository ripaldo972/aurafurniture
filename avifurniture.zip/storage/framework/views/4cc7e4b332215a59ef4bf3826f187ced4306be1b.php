<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h1>DASHBOARD</h1>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\avifurniture\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>