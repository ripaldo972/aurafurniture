<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <title>Dashboard</title>
    <!-- CSS files -->
    <link href="<?php echo e(asset('assets/admin/dist/css/tabler.min.css')); ?>" rel="stylesheet"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/dist/css/custome.css')); ?>">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <!-- Logo -->
    <link rel="icon" href="" id="logoIcon">
    <?php echo $__env->yieldContent('css'); ?>
  </head>
  <body >
    <div class="page">
        <!-- Sidebar -->
        <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Navbar -->
        <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-wrapper">
            <div class="page-body">
                <div class="container-xl">
                    <div class="row">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <!-- Tabler Core -->
    <script src="<?php echo e(asset('assets/admin/dist/js/tabler.min.js')); ?>" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
    <script src="<?php echo e(asset('assets/admin/api/logo.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>
  </body>
</html>
<?php /**PATH C:\laragon\www\avifurniture\resources\views/admin/layouts/general.blade.php ENDPATH**/ ?>