<div class="col-xxl-3 col-xl-4 col-lg-5 d-none d-lg-block wow fadeInUp">
    <div class="right-sidebar-box">
        <div class="vendor-box">
            <div class="vendor-list">
                <ul>
                    <li>
                        <div class="address-contact">
                            <i data-feather="map-pin"></i>
                            <h5>Address: <span class="text-content" id="address"></span></h5>
                        </div>
                    </li>

                    <li>
                        <div class="address-contact">
                            <i data-feather="headphones"></i>
                            <h5>Contact Seller: <span class="text-content" id="phone"></span></h5>
                        </div>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Trending Product -->
        <div class="pt-25">
            <div class="category-menu">
                <h3>Lokasi</h3>
                <div id="location">

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\avifurniture\resources\views/layouts/right-bar.blade.php ENDPATH**/ ?>