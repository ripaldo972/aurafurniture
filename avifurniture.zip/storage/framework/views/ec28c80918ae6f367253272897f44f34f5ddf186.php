<?php $__env->startSection('css'); ?>
<style>

    .page-item.active .page-link {
        z-index: 3;
        color: #fff;
        background-color: #0baf9a;
        border-color: #0baf9a;
    }

    .page-link  {
        color: #0baf9a;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="breadscrumb-section pt-0">
    <div class="container-fluid-lg">
        <div class="row">
            <div class="col-12">
                <div class="breadscrumb-contain">
                    <h2>Workshops</h2>
                    <nav>
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(url('/')); ?>">
                                    Home
                                </a>
                            </li>
                            <li class="breadcrumb-item active">Workshops</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="product-section">
    <div class="container-fluid-lg">
        <div class="row">
            <?php $__currentLoopData = $workshops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 mb-3">
                    <div class="card shadow-sm">
                        <img src="<?php echo e(asset('uploads/workshop/'.$result->image)); ?>" alt="" width="100%" height="300">
                        <div class="card-body">
                            <h3 class="d-block mb-3"><?php echo e($result->title); ?></h3>
                            <div class="d-flex justify-content-between">
                                <h5 class="text-muted"><?php echo e($result->address); ?></h5>
                                <h6 class="text-muted"><?php echo e(date('l, d F Y', strtotime($result->date))); ?></h6>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<section class="product-section mb-3">
    <div class="d-flex justify-content-center">
        <?php echo e($workshops->links()); ?>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\avifurniture\resources\views/workshop.blade.php ENDPATH**/ ?>