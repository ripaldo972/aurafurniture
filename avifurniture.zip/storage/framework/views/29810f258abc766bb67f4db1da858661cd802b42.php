<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/plugin/summernote/summernote-lite.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h1>ABOUT</h1>
</div>

<div class="col-md-12">
    <form action="<?php if(!empty($about)): ?> <?php echo e(route('about.update', Crypt::encrypt($about->id))); ?> <?php else: ?> <?php echo e(route('about.store')); ?> <?php endif; ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if(!empty($about)): ?>
            <?php echo method_field('patch'); ?>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-8 mb-3">
                <div class="mb-4">
                    <input type="text" name="title" placeholder="Astro Cloud Software Developer" class="form-control form-title mb-2" id="nameProduct" onkeyup="permalink()" <?php if(!empty($about)): ?> value="<?php echo e($about->title); ?>" <?php endif; ?>>
                    <div>Permalink : <?php echo e(url('/')); ?>/about-us/<span id="setName"><?php if(!empty($about)): ?><?php echo e($about->slug); ?> <?php endif; ?></span> </div>
                </div>
                <div class="mb-3">
                    <textarea name="content" id="content"><?php if(!empty($about)): ?><?php echo e($about->content); ?><?php endif; ?></textarea>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="d-flex justify-content-end">
                    <div class="card card-95">
                        <div class="card-body">
                            <div class="mb-3">
                                <label class="form-label">Meta Keywords</label>
                                <input type="text" class="form-control" name="meta_keywords" placeholder="SEO for google" <?php if(!empty($about)): ?> value="<?php echo e($about->meta_keywords); ?>" <?php endif; ?>>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Meta Description</label>
                                <textarea name="meta_description" class="form-control" style="height: 100px;" placeholder="SEO for google"><?php if(!empty($about)): ?><?php echo e($about->meta_description); ?><?php endif; ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">
                                    <div class="d-flex justify-content-between">
                                        <span>Image</span>
                                        <?php if(!empty($about)): ?>
                                            <a href="<?php echo e(asset('uploads/about/'.$about->image)); ?>" target="_blank">View image</a>
                                        <?php endif; ?>
                                    </div>
                                </label>
                                <?php if(!empty($about)): ?>
                                    <input type="file" class="form-control" name="image" accept="image/*">
                                <?php else: ?>
                                    <input type="file" class="form-control" name="image" accept="image/*" required>
                                <?php endif; ?>

                            </div>
                            <div class="mb-3">
                                <div class="d-flex justify-content-end">
                                    <button class="btn btn-primary">Save Changes</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/admin/plugin/summernote/summernote-lite.js')); ?>"></script>

<script>
    $('#content').summernote({
        placeholder: 'Create your content here',
        tabsize: 2,
        height: 350,
        toolbar: [
                ['style', ['style']],
                ['font', ['bold', 'underline', 'clear']],
                ['color', ['color']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['table', ['table']],
                ['insert', ['link', 'picture', 'video']],
        ]
    });
</script>

<script src="<?php echo e(asset('assets/admin/dist/js/permalink.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\avifurniture\resources\views/admin/about/index.blade.php ENDPATH**/ ?>