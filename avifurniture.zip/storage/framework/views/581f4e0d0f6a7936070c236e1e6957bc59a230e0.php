<?php $__env->startSection('content'); ?>

<div class="col-md-12 mb-3">
    <h1>GENERAL SETTINGS</h1>
</div>

<div class="col-md-6">
    <form action="<?php if(!empty($setting)): ?> <?php echo e(route('setting.update', Crypt::encrypt($setting->id))); ?> <?php else: ?> <?php echo e(route('setting.store')); ?> <?php endif; ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if(!empty($setting)): ?>
            <?php echo method_field('patch'); ?>
        <?php endif; ?>
        <div class="row align-items-center">
            <div class="col-md-4 mb-3 col-4">
                <label class="form-label">Nama Website</label>
            </div>
            <div class="col-md-8 mb-3 col-8">
                <input type="text" class="form-control" name="name" placeholder="Astro Cloud" <?php if(!empty($setting)): ?> value="<?php echo e($setting->name); ?>" <?php endif; ?>>
            </div>
            <div class="col-md-4 mb-3 col-4">
                <label class="form-label">Alamat</label>
            </div>
            <div class="col-md-8 mb-3 col-8">
                <input type="text" class="form-control" name="address" placeholder="Malang, Jawa Timur" <?php if(!empty($setting)): ?> value="<?php echo e($setting->address); ?>" <?php endif; ?>>
            </div>
            <div class="col-md-4 mb-3 col-4">
                <label class="form-label">Email</label>
            </div>
            <div class="col-md-8 mb-3 col-8">
                <input type="email" class="form-control" name="email" placeholder="astrocloud@gmail.com" <?php if(!empty($setting)): ?> value="<?php echo e($setting->email); ?>" <?php endif; ?>>
                <span class="text-muted"><i>Email ini akan digunakan untuk notifikasi ke admin ketika ada pemesanan via email dan contact via email</i></span>
            </div>
            <div class="col-md-4 mb-3 col-4">
                <label class="form-label">Nomor Telepon</label>
            </div>
            <div class="col-md-8 mb-3 col-8">
                <input type="text" maxlength="15" class="form-control" name="phone" placeholder="0895410376876" <?php if(!empty($setting)): ?> value="<?php echo e($setting->phone); ?>" <?php endif; ?>>
                <span class="text-muted"><i>Nomor ini akan digunakan untuk user terkoneksi langsung ke nomor telepon Admin</i></span>
            </div>
            <div class="col-md-4 mb-3 col-4">
                <label class="form-label">Link Instagram</label>
            </div>
            <div class="col-md-8 mb-3 col-8">
                <input type="text" class="form-control" name="instagram" placeholder="https://instagram.com/astro.cloud" <?php if(!empty($setting)): ?> value="<?php echo e($setting->instagram); ?>" <?php endif; ?>>
            </div>
            <div class="col-md-4 mb-3 col-4">
                <label class="form-label">Link Facebook</label>
            </div>
            <div class="col-md-8 mb-3 col-8">
                <input type="text" class="form-control" name="facebook" placeholder="https://faecbook.com/astro_cloud" <?php if(!empty($setting)): ?> value="<?php echo e($setting->facebook); ?>" <?php endif; ?>>
            </div>
            <div class="col-md-4 mb-3 col-4">
                <label class="form-label">Link Yotube</label>
            </div>
            <div class="col-md-8 mb-3 col-8">
                <input type="text" class="form-control" name="youtube" placeholder="https://youtube.com/astro.cloud" <?php if(!empty($setting)): ?> value="<?php echo e($setting->youtube); ?>" <?php endif; ?>>
            </div>
            <div class="col-md-4 mb-3 col-4">
                <label class="form-label">Link Tiktok</label>
            </div>
            <div class="col-md-8 mb-3 col-8">
                <input type="text" class="form-control" name="tiktok" placeholder="https://tiktok.com/astro_cloud" <?php if(!empty($setting)): ?> value="<?php echo e($setting->tiktok); ?>" <?php endif; ?>>
            </div>
            <div class="col-md-4 mb-3 col-4">
                <label class="form-label">Whastapp</label>
            </div>
            <div class="col-md-8 mb-3 col-8">
                <input type="text" maxlength="15" class="form-control" name="whatsapp" placeholder="0895410376876" <?php if(!empty($setting)): ?> value="<?php echo e($setting->whatsapp); ?>" <?php endif; ?>>
                <span class="text-muted"><i>Whatsapp ini akan digunakan untuk user terkoneksi langsung ke nomor telepon Admin</i></span>
            </div>
            <div class="col-md-4 mb-3 col-4">
                <label class="form-label">Embeb Location</label>
                <span>
                    <a href="" target="_blank">Tutorial</a>
                </span>
            </div>
            <div class="col-md-8 mb-3 col-8">
                <textarea class="form-control" name="location" style="height: 100px;" placeholder="Embed Your Location"><?php if(!empty($setting)): ?><?php echo e($setting->location); ?><?php endif; ?></textarea>
                <span class="text-muted"><i>The location will be used and applied to the website</i></span>
            </div>
            <div class="col-md-4 mb-3 col-4">
                <label class="form-label">Logo</label>
            </div>
            <div class="col-md-8 mb-3 col-8">
                <input type="file" class="form-control" name="logo">
            </div>
            <div class="col-md-4 mt-4 col-4">
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            </div>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\avifurniture\resources\views/admin/setting/index.blade.php ENDPATH**/ ?>