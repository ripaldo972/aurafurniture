<?php $__env->startSection('meta'); ?>
<meta name="keywords" content="<?php echo e($faq->meta_keywords); ?>">
<meta name="description" content="<?php echo e($faq->meta_description); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="breadscrumb-section pt-0">
    <div class="container-fluid-lg">
        <div class="row">
            <div class="col-12">
                <div class="breadscrumb-contain">
                    <h2><?php echo e($faq->title); ?></h2>
                    <nav>
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(url('/')); ?>">
                                    Home
                                </a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo e($faq->title); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="product-section mb-5">
    <div class="container-fluid-lg">
        <div class="row">
            <div class="col-xxl-9 col-xl-8 col-lg-7 wow fadeInUp">
                <div class="row g-4">
                    <div class="col-md-12">
                        <img src="<?php echo e(asset('uploads/faq/'.$faq->image)); ?>" alt="" width="100%" height="300">
                    </div>
                    <div class="col-md-12 mb-3">
                        <?php echo $faq->content; ?>

                    </div>
                </div>
            </div>

            <?php echo $__env->make('layouts.right-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/user/api/contact_information.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/api/location.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\avifurniture\resources\views/faq.blade.php ENDPATH**/ ?>